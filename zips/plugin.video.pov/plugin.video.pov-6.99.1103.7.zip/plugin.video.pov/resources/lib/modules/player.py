import json
from threading import Thread
from time import monotonic
from caches import watched_cache as ws
from indexers.metadata import art_infodict, episode_infodict, info_tagger, movie_show_infodict
from indexers.segments import SegmentScraper
from modules import kodi_utils, settings
from modules.utils import sec2time

HANDOFF_DEFERRED, HANDOFF_FAILED = object(), object()
HANDOFF_STOP_WAIT = 2.0   # R10.45: longest wait for the held episode to close before the successor opens
# from modules.kodi_utils import logger

KODI_VERSION, make_cast_list = kodi_utils.get_kodi_version(), kodi_utils.make_cast_list
ls, get_setting, get_visibility = kodi_utils.local_string, kodi_utils.get_setting, kodi_utils.get_visibility
get_art_provider, meta_user_info = settings.get_art_provider, settings.metadata_user_info
fanart_empty = kodi_utils.get_addoninfo('fanart')
poster_empty = kodi_utils.media_path('box_office.png')
resumept_str, resume_str, start_str = ls(32831), ls(32832), ls(32833)

class MediaPlayer(kodi_utils.xbmc_player):
	def __init__(self):
		kodi_utils.xbmc_player.__init__(self)
		self.playback_event = None

	def windowIsActive(self):
		return any(get_visibility(i) for i in ('Window.IsActive(fullscreenvideo)', 'Window.IsActive(videoosd)'))

	def onAVStarted(self):
		self.playback_event = True

	def onPlayBackStarted(self):
		try: kodi_utils.hide_busy_dialog()
		except: pass

	def onPlayBackEnded(self):
		self.playback_event = None

	def onPlayBackStopped(self):
		self.playback_event = None

	def onPlayBackError(self):
		self.playback_event = None

class POVPlayer(MediaPlayer):
	def __init__(self):
		MediaPlayer.__init__(self)
		self.monitor = kodi_utils.xbmc_monitor()
		self.set_resume, self.set_watched = 5, 80
		self.media_marked = False
		self.next_episode = None
		self.nextep_settings = None
		self.subs_searched, self.stingers_checked = False, False
		self.play_random_continual = False
		self.autoplay_next_episode = False
		self.autoplay_nextep = settings.autoplay_next_episode()
		self.autoscrape_next_episode = False
		self.autoscrape_nextep = settings.autoscrape_next_episode()
		self.art_provider = (*get_art_provider(), poster_empty, fanart_empty)
		self.stinger_enabled = get_setting('stingers.enable') == 'true'
		self.stinger_check = int(get_setting('stingers.threshold', '30'))
		self.skip_intro_enabled = get_setting('skip_intro.enable') == 'true'
		self.volume_check = get_setting('volumecheck.enabled', 'false') == 'true'

	def run(self, url, filename, meta, progress_media=None, resume_action=None, next_flight=None, previous=None):
		if not url: return
		try:
			self.meta = meta or {}
			self.meta_get = self.meta.get
			self.filename = filename or ''
			self.tmdb_id, self.imdb_id = self.meta_get('tmdb_id'), self.meta_get('imdb_id')
			self.title, self.year = self.meta_get('title'), self.meta_get('year')
			self.mediatype, self.tvdb_id = self.meta_get('mediatype'), self.meta_get('tvdb_id')
			self.season, self.episode = self.meta_get('season', ''), self.meta_get('episode', '')
			self.resume_seconds = 0   # R10.55.3 FIX C: set by check_bookmarks() when the bookmark has a stop time
			# A series-details restart starts at zero without deleting the stored bookmark.
			if resume_action == 'restart' or any(i in self.meta for i in ('random', 'random_continual')): bookmark = 0
			else: bookmark = self.check_bookmarks(force_resume=resume_action == 'resume')
			if bookmark == 'cancel': return progress_media() if callable(progress_media) else None
			self.meta.update({'url': url, 'bookmark': bookmark})
			listitem = self.make_listitem()
			listitem.setContentLookup(False)
			listitem.setLabel(self.title)
			listitem.setArt(art_infodict(self.meta, self.art_provider, meta_user_info()))
			listitem.setPath(url)
			# R10.55.3 FIX C: Kodi 21 reads a string StartPercent as a whole number (CVariant::asDouble -> str2uint64: "14.9"
			# is 14), so every resume went back to the whole percent (up to 1 % of the runtime). When the bookmark has its
			# stop time, StartOffset (seconds, decimals kept) starts where set_bookmark's percent points; Kodi zeroes the
			# offset when a StartPercent is present, so then none is set. Bookmarks without a time (Trakt / MDBList progress)
			# and 0 (start at the beginning) keep StartPercent as before.
			if bookmark and self.resume_seconds > 0: listitem.setProperty('StartOffset', '%.3f' % self.resume_seconds)
			else: listitem.setProperty('StartPercent', str(bookmark))

			self.playback_event = False
			if previous is None:
				self.play(listitem.getPath(), listitem)
				while self.playback_event is False: kodi_utils.sleep(100)
			else:
				started = self.complete_replacement(previous, listitem)
				if started is not True: return started or None
			if self.playback_event and self.mediatype in ('movie', 'episode'):
				original = self.meta_get('original_language')
				if not original or original == 'en':
					Thread(target=self.select_original_english, args=(original,), daemon=True).start()
			if callable(progress_media): progress_media()
			if previous is None: kodi_utils.close_all_dialog()
			self.exec_task('trakt_ids')
			if self.mediatype == 'episode':
				self.play_random_continual = 'random_continual' in self.meta
				if not self.play_random_continual and self.autoplay_nextep:
					self.autoplay_next_episode = 'random' not in self.meta
				if not self.play_random_continual and self.autoscrape_nextep:
					self.autoscrape_next_episode = 'random' not in self.meta
				if not self.play_random_continual and self.autoplay_nextep and self.autoscrape_nextep:
					self.autoscrape_next_episode = False
				if next_flight is not None and next_flight.owns_playback():
					from modules.netflix_next_episode import NextEpisodeController
					self.next_episode = NextEpisodeController(self, next_flight)
					if not self.autoplay_next_episode: self.next_episode.model.dismiss()
				self.exec_task('episode_handler')
			if self.volume_check: kodi_utils.volume_checker()
			return self.watch()
		except RuntimeError:
			if previous is not None and previous.next_episode.owns_playback():
				return HANDOFF_FAILED
			self.finish_owner()
		except Exception:
			self.finish_owner()

	def matching_video(self, expected, path):
		from modules.netflix_next_episode import playing_episode
		try:
			return (self.isPlayingVideo() and playing_episode(self) == expected
					and self.getPlayingFile().split('|', 1)[0] == path)
		except RuntimeError:
			return False

	def onAVStarted(self):
		event = self.playback_event
		if isinstance(event, tuple):
			expected, path, owner, acknowledged = event
			if not acknowledged and self.matching_video(expected, path):
				if owner.exiting() and owner.flight.owns_playback():
					# An asynchronous successor can reach AV after the viewer's Stop.
					# Stop only the exact file and episode dispatched by this request.
					self.playback_event = None
					self.stop()
				else:
					self.playback_event = expected, path, owner, True
		else:
			super().onAVStarted()

	def onPlayBackStopped(self):
		# Kodi can deliver the preceding video's Stop/Ended after the replacement's AV callback.
		if not isinstance(self.playback_event, tuple): super().onPlayBackStopped()

	def onPlayBackEnded(self):
		if not isinstance(self.playback_event, tuple): super().onPlayBackEnded()

	def onPlayBackSeek(self, position, offset):
		owner = self.next_episode
		if owner is not None: owner.model.defer()

	def watch(self):
		while self.isPlayingVideo():
			replacement = self.check_playback_events()
			if replacement is not None:
				return replacement
		self.finish_watch()

	def finish_watch(self, replacement=False):
		owner = self.next_episode
		if owner is not None:
			owner.close(handoff=replacement)
		if not self.media_marked: self.media_watched_marker()
		kodi_utils.clear_local_bookmarks()
		kodi_utils.clear_property('script.trakt.ids')

	def finish_owner(self):
		owner = self.next_episode
		if owner is not None: self.finish_watch()

	def complete_replacement(self, previous, listitem):
		owner = previous.next_episode
		if not owner.can_commit():
			return HANDOFF_DEFERRED
		expected = str(self.tmdb_id), int(self.season), int(self.episode)
		link = listitem.getPath()
		handed = False
		try:
			from modules.sources import Sources
			if not Sources.update_series_return(owner.flight, 'video', expected): return HANDOFF_FAILED
			if not owner.can_commit():
				if not owner.exiting(): Sources.update_series_return(owner.flight, 'video', owner.identity)
				return HANDOFF_DEFERRED
			path = link.split('|', 1)[0]
			self.playback_event = expected, path, owner, False
			if not self.release_previous(owner): return HANDOFF_FAILED
			sent = monotonic()
			self.play(link, listitem)
			kodi_utils.logger('Netflix Next', 'play() returned after %.2f s' % (monotonic() - sent))
			# Reuse initial playback's native AV/error/abort events for slow starts.
			while self.playback_event is not None and owner.flight.owns_playback():
				if owner.exiting():
					# Kodi posts Play to the application FIFO; Player.stop sends to that
					# same queue synchronously and aborts the native opening. It also
					# covers a Stop pressed just before this request posted Play.
					if owner.flight.owns_playback() and (not self.isPlayingVideo() or self.matching_video(expected, path)
							or self.matching_video(owner.identity, owner.file.split('|', 1)[0])):
						self.stop()
					return HANDOFF_FAILED
				if self.playback_event == (expected, path, owner, True) and self.matching_video(expected, path):
					self.playback_event = True
					previous.finish_watch(replacement=True)
					handed = True
					return True
				if self.monitor.waitForAbort(0.1): break
			return HANDOFF_FAILED
		except Exception:
			# Once Play has been dispatched, its result is ambiguous. Never dispatch it again.
			return HANDOFF_FAILED
		finally:
			owner.hide()
			# R10.45: the planned Stop leaves fullscreen video; Kodi may refuse to switch back while the card
			# (a modal dialog) is up, so return to it once the card is hidden.
			if handed and self.isPlayingVideo() and not get_visibility('Window.IsActive(fullscreenvideo)'):
				kodi_utils.execute_builtin('ActivateWindow(fullscreenvideo)')

	def release_previous(self, owner):
		# R10.45: Android has one hardware video decoder. Play over the held episode leaves the
		# successor without it (InstanceGuard locked: audio only, black screen). Stop first and
		# open only once Kodi reports nothing playing. The card's black hand-off stays up.
		# This player's tuple event keeps the planned Stop out of onPlayBackStopped; no exit
		# property is written, so the show page and owner.exiting() ignore it. A viewer's Stop
		# (Netflix.Exit.NoNext) or a lost flight cancels; no release within the bound fails.
		began = monotonic()
		self.stop()
		deadline = began + HANDOFF_STOP_WAIT
		while owner.flight.owns_playback() and not owner.exiting():
			# R10.46: isPlaying() alone: Kodi reports it False once the old file is closed (Player.HasMedia lagged).
			if not self.isPlaying():
				kodi_utils.logger('Netflix Next', 'decoder released %.2f s after stop' % (monotonic() - began))
				return True
			if monotonic() >= deadline or self.monitor.waitForAbort(0.05): break
		return False

	def select_original_english(self, original):
		def audio_properties():
			request = {
				'jsonrpc': '2.0', 'id': 1, 'method': 'Player.GetProperties',
				'params': {'playerid': 1, 'properties': ['currentaudiostream', 'audiostreams']},
			}
			return json.loads(kodi_utils.execJSONRPC(json.dumps(request))).get('result', {})

		def is_english(stream):
			return stream.get('language', '').lower() in ('en', 'eng')

		try:
			if not self.isPlayingVideo(): return
			file = self.getPlayingFile()
			deadline = monotonic() + 5
			properties = audio_properties()
			current = properties.get('currentaudiostream') or {}
			if 'index' not in current or is_english(current): return
			english = [
				stream for stream in properties.get('audiostreams', [])
				if is_english(stream) and not stream.get('isimpaired')
				and 'commentary' not in stream.get('name', '').lower()
			]
			if not english: return
			if not original:
				media_id = str(self.tmdb_id or '')
				if not media_id.isascii() or not media_id.isdecimal() or int(media_id) == 0: return
				from indexers.tmdb_api import tmdb_original_language
				original = tmdb_original_language('tv' if self.mediatype == 'episode' else 'movie', media_id)
			if original != 'en' or monotonic() > deadline: return
			# A metadata lookup can outlive this video or a manual audio change.
			if not self.isPlayingVideo() or self.getPlayingFile() != file: return
			now = audio_properties().get('currentaudiostream') or {}
			if now.get('index') != current['index']: return
			best = max(english, key=lambda stream: (
				stream.get('isoriginal', False), stream.get('channels', 0), stream.get('isdefault', False),
			))
			self.setAudioStream(best['index'])
		except (KeyError, TypeError, ValueError, RuntimeError, OSError):
			return

	def check_playback_events(self):
		try:
			owner = self.next_episode
			self.monitor.waitForAbort(owner.poll_interval() if owner else 1)
			self.total_time, self.curr_time = self.getTotalTime(), self.getTime()
			self.current_point = round(float(self.curr_time/self.total_time * 100), 1)
			self.remaining_time = round(self.total_time - self.curr_time)
			if not self.subs_searched:
				self.exec_task('subtitles')
			if not self.stingers_checked and self.mediatype == 'movie':
				if self.stinger_enabled and self.curr_time > self.stinger_check:
					self.exec_task('stingers')
			if not self.media_marked:
				if self.current_point >= self.set_watched:
					self.media_watched_marker()
			if owner is not None:
				if hasattr(self, 'credits'):
					return owner.tick(self.curr_time, self.total_time, self.credits)
			elif self.nextep_settings is not None:
				if self.play_random_continual and self.remaining_time <= self.start_prep:
					self.exec_task('random_continual')
				elif self.autoplay_next_episode and self.remaining_time <= self.start_prep:
					if self.autoplay_nextep: self.exec_task('next_ep')
				elif self.autoscrape_next_episode and self.remaining_time <= self.autoscrape_next_window_time:
					if self.autoscrape_nextep: self.exec_task('scrape_next_ep')
		except: pass

	def make_listitem(self):
		listitem = kodi_utils.make_listitem()
		try:
			if self.mediatype == 'movie':
				info = movie_show_infodict(self.meta)
				uids = {'imdb': self.imdb_id, 'tmdb': str(self.tmdb_id)}
			else:
				info = {**episode_infodict(self.meta), 'title': self.meta_get('ep_name')}
				uids = {'imdb': self.imdb_id, 'tmdb': str(self.tmdb_id), 'tvdb': str(self.tvdb_id)}
			if KODI_VERSION < 20:
				listitem.setInfo('video', info)
				listitem.setUniqueIDs(uids)
				listitem.setCast(self.meta_get('cast', []))
			else:
				infotag = info_tagger(listitem, info)
				infotag.setUniqueIDs(uids)
				infotag.setCast(make_cast_list(self.meta_get('cast', [])))
		except: pass
		return listitem

	def check_bookmarks(self, force_resume=False):
		watched_indicators = settings.watched_indicators()
		bookmarks = ws.get_bookmarks(watched_indicators, self.mediatype)
		try: resume_point, curr_time, resume_id = ws.detect_bookmark(bookmarks, self.tmdb_id, self.season, self.episode)
		except: resume_point, curr_time = 0, 0
		resume_check = float(resume_point)
		if not resume_check: return 0
		percent = str(resume_point)
		# R10.55.3 FIX C: set_bookmark stores the stop time and the percent of (stop time - 5 s): resume at that second
		try: self.resume_seconds = max(0.0, float(curr_time) - 5)
		except (TypeError, ValueError): self.resume_seconds = 0
		raw_time = float(curr_time)
		if watched_indicators in (1, 2): resume_point = '%s%%' % str(percent)
		else: resume_point = sec2time(raw_time, n_msec=0)
		if not force_resume and not settings.auto_resume(self.mediatype):
			from windows import open_window
			choice = open_window(
				('windows.progress', 'ProgressMedia'),
				'progress_media.xml',
				meta=self.meta,
				text=resumept_str % resume_point,
				enable_buttons=True,
				true_button=resume_str,
				false_button=start_str,
				focus_button=10,
				percent=percent
			)
			bookmark = percent if choice is True else 0 if choice is False else 'cancel'
		else: bookmark = percent
		if bookmark == 0:
			ws.erase_bookmark(self.mediatype, self.tmdb_id, self.season, self.episode, timeout=0.5)
		return bookmark

	def stinger_notification(self, tmdb_id, poster):
		if not tmdb_id: return
		from indexers import tmdb_api
		stingers = {'duringcreditsstinger': 'During Credit Scene', 'aftercreditsstinger': 'After Credit Scene'}
		keywords = tmdb_api.movie_keywords(tmdb_id) or []
		keywords = {str(i['name']) for i in keywords}
		if all((i in keywords for i in stingers.keys())): stinger = 'Dual Credit Scenes'
		else: stinger = next((v for k, v in stingers.items() if k in keywords), None)
		if stinger: kodi_utils.notification(stinger, time=6000, icon=poster)

	def episode_handler(self):
		for _ in range(150):
			total_time = False
			try: total_time = self.getTotalTime() > 0
			except: pass
			if total_time: break
			kodi_utils.sleep(200)
		else: return
		self.intro, self.credits = SegmentScraper(self.imdb_id, self.season, self.episode).run()
		if self.skip_intro_enabled:
			if self.intro is None:
				kodi_utils.logger('POV Skip Intro', 'No marker returned for this episode.')
			else:
				kodi_utils.logger('POV Skip Intro', 'Marker window %s–%s seconds.' % self.intro)
				self.exec_task('skip_intro')
		if self.next_episode is None and (self.play_random_continual or self.autoplay_next_episode or self.autoscrape_next_episode):
			self.info_next_ep()

	def info_next_ep(self):
		try:
			next_settings = settings.autoplay_next_settings()
			if self.credits is not None and self.credits <= self.getTotalTime():
				window_time = round(self.getTotalTime() - self.credits + 5)
				next_settings['window_time'] = window_time
				next_settings['autoscrape_next_window_time'] = window_time
			elif not next_settings['run_popup']:
				window_time = round(0.02 * self.getTotalTime())
				next_settings['window_time'] = window_time
			elif next_settings['timer_method'] == 'percentage':
				percentage = next_settings['window_percentage']
				window_time = round((percentage/100) * self.getTotalTime())
				next_settings['window_time'] = window_time
			else:
				window_time = next_settings['window_time']
			threshold_check = window_time + 21
			self.start_prep = next_settings['scraper_time'] + threshold_check
			next_settings.update({'threshold_check': threshold_check, 'start_prep': self.start_prep})
			self.autoscrape_next_window_time = next_settings['autoscrape_next_window_time']
			self.nextep_settings = next_settings
		except Exception: self.nextep_settings = None

	def media_watched_marker(self):
		self.media_marked = True
		try:
			if self.current_point >= self.set_watched:
				if self.mediatype == 'movie': watched_params, watched_function = {
					'mode': 'mark_as_watched_unwatched_movie', 'action': 'mark_as_watched',
					'refresh': 'false', 'from_playback': 'true',
					'tmdb_id': self.tmdb_id, 'title': self.title, 'year': self.year
					}, ws.mark_as_watched_unwatched_movie
				else: watched_params, watched_function = {
					'mode': 'mark_as_watched_unwatched_episode', 'action': 'mark_as_watched',
					'refresh': 'false', 'from_playback': 'true',
					'tmdb_id': self.tmdb_id, 'title': self.title, 'year': self.year,
					'tvdb_id': self.tvdb_id, 'season': self.season, 'episode': self.episode
					}, ws.mark_as_watched_unwatched_episode
				return self.exec_task('media_watched', watched_function, watched_params)
			kodi_utils.clear_property('pov_total_autoplays')
			if self.current_point < self.set_resume: return
			self.exec_task(
				'media_bookmark', self.mediatype,
				self.tmdb_id, self.curr_time, self.total_time,
				self.title, self.season, self.episode
			)
		except: pass

	def exec_task(self, task_name, *args):
		try:
			if task_name == 'media_bookmark':
				# isPlayingVideo is False before onPlayBackStopped called, ensure player cleanup
				# completed or container_refresh in set_bookmark will sometimes crash container
				_ = any(kodi_utils.sleep(300) or not self.windowIsActive() for i in range(5))
				if args:
					if kodi_utils.netflix_skin(): ws.set_bookmark(*args, refresh='false')
					else: ws.set_bookmark(*args)
			elif task_name == 'media_watched':
				if args: Thread(target=args[0], args=(args[1],)).start()
			elif task_name == 'episode_handler':
				Thread(target=self.episode_handler).start()
			elif task_name == 'skip_intro':
				from modules.episode_tools import execute_skip_intro
				Thread(target=execute_skip_intro, args=(self, self.meta)).start()
			elif task_name == 'scrape_next_ep':
				self.nextep_settings = None
				from modules.episode_tools import execute_scrape_nextep
				Thread(target=execute_scrape_nextep, args=(self, self.meta)).start()
			elif task_name in ('next_ep', 'random_continual'):
				next_settings, self.nextep_settings = self.nextep_settings, None
				from modules.episode_tools import execute_nextep
				Thread(target=execute_nextep, args=(self, self.meta, next_settings)).start()
			elif task_name == 'subtitles':
				self.subs_searched = True
				poster = self.meta.get('poster') or poster_empty
				from indexers.subtitles import SubtitleScraper
				Thread(target=SubtitleScraper(self, poster)).start()
			elif task_name == 'stingers':
				self.stingers_checked = True
				poster = self.meta.get('poster') or poster_empty
				tmdb_id = self.tmdb_id if self.mediatype == 'movie' and self.stinger_enabled else None
				Thread(target=self.stinger_notification, args=(tmdb_id, poster)).start()
			elif task_name == 'trakt_ids':
				trakt_ids = {'tmdb': self.tmdb_id, 'imdb': self.imdb_id}
				if self.mediatype == 'episode': trakt_ids['tvdb'] = self.tvdb_id
				kodi_utils.clear_property('script.trakt.ids')
				kodi_utils.set_property('script.trakt.ids', json.dumps(trakt_ids))
		except: pass

